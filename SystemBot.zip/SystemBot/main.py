import uvicorn
from fastapi import FastAPI, Form, Response
from pymongo import MongoClient
from twilio.twiml.voice_response import VoiceResponse, Gather
from datetime import datetime
import pytz # Import timezone library
from typing import Optional

app = FastAPI(title="Voice Support Bot (IST)")

# --- 1. DATABASE CONNECTION ---
client = MongoClient('mongodb://localhost:27017/')
db = client['voice_support_db']
call_logs = db['call_logs']

# --- 2. TIMEZONE HELPER (IST) ---
def get_ist_time():
    """Returns current time in India as a formatted string."""
    ist_zone = pytz.timezone('Asia/Kolkata')
    # Get current time in IST
    now_ist = datetime.now(ist_zone)
    # Format it nicely: Year-Month-Day Hour:Minute:Second
    return now_ist.strftime("%Y-%m-%d %H:%M:%S")

# --- 3. KNOWLEDGE BASE ---
def query_knowledge_base(text: str):
    if not text: return None
    text = text.lower()
    
    if 'password' in text:
        return "To reset your password, visit our website and click 'Forgot Password'."
    elif 'hours' in text or 'open' in text:
        return "We are open from 9 AM to 5 PM IST, Monday through Friday."
    return None

# --- 4. TRANSFER HELPER ---
def get_transfer_twiml(call_sid: str):
    call_logs.update_one(
        {'call_sid': call_sid},
        {'$set': {'transferred_to_human': True}}
    )
    resp = VoiceResponse()
    resp.say("Transferring you to a human agent. Please hold.")
    resp.dial("+919876543210") # Example Indian number
    return Response(content=str(resp), media_type="application/xml")

# ==========================================
#  SECTION A: VOICE BOT WEBHOOKS
# ==========================================

@app.post("/voice/incoming")
async def incoming_call(
    CallSid: str = Form(...), 
    From: str = Form(...)
):
    # --- IST CHANGE HERE ---
    ist_now = get_ist_time()

    call_logs.insert_one({
        'call_sid': CallSid,
        'caller_number': From,
        'status': 'initiated',
        'start_time': ist_now, # Saved as IST String
        'transferred_to_human': False,
        'user_query': None,
        'duration': 0
    })

    resp = VoiceResponse()
    gather = Gather(input='speech', action='/voice/process', timeout=3)
    gather.say("Welcome. State your problem, or say human to speak to an agent.")
    resp.append(gather)
    resp.say("We didn't hear anything. Goodbye.")
    
    return Response(content=str(resp), media_type="application/xml")

@app.post("/voice/process")
async def process_speech(
    CallSid: str = Form(...),
    SpeechResult: Optional[str] = Form(None)
):
    if SpeechResult:
        call_logs.update_one({'call_sid': CallSid}, {'$set': {'user_query': SpeechResult}})
        user_speech = SpeechResult.lower()
    else:
        user_speech = ""

    if 'human' in user_speech or 'agent' in user_speech:
        return get_transfer_twiml(CallSid)

    solution = query_knowledge_base(user_speech)

    resp = VoiceResponse()
    if solution:
        resp.say(f"Here is the solution: {solution}")
        gather = Gather(input='speech', action='/voice/satisfaction', timeout=3)
        gather.say("Did that help? Say yes or no.")
        resp.append(gather)
    else:
        resp.say("I couldn't find a solution.")
        return get_transfer_twiml(CallSid)

    return Response(content=str(resp), media_type="application/xml")

@app.post("/voice/satisfaction")
async def satisfaction_check(
    CallSid: str = Form(...),
    SpeechResult: Optional[str] = Form(None)
):
    resp = VoiceResponse()
    speech = SpeechResult.lower() if SpeechResult else ""

    if 'no' in speech or 'not' in speech:
        resp.say("I am sorry.")
        return get_transfer_twiml(CallSid)
    else:
        resp.say("Great! Goodbye.")
        resp.hangup()
        
    return Response(content=str(resp), media_type="application/xml")

@app.post("/voice/status")
async def call_status(
    CallSid: str = Form(...),
    CallStatus: str = Form(...),
    CallDuration: Optional[str] = Form(None)
):
    duration_int = int(CallDuration) if CallDuration else 0
    
    # --- IST CHANGE HERE ---
    ist_now = get_ist_time()

    call_logs.update_one(
        {'call_sid': CallSid},
        {'$set': {
            'status': CallStatus,
            'duration': duration_int,
            'end_time': ist_now # Saved as IST String
        }}
    )
    return {"message": "Log updated"}

# ==========================================
#  SECTION B: CONFIGURATION API
# ==========================================

@app.get("/api/logs")
async def get_logs():
    """Retrieve all call logs."""
    logs = []
    # Sort by start_time (String sort works for YYYY-MM-DD format)
    for log in call_logs.find().sort("start_time", -1):
        log['_id'] = str(log['_id'])
        logs.append(log)
    return {"count": len(logs), "data": logs}

@app.get("/api/analytics")
async def get_analytics():
    """Get statistics."""
    total = call_logs.count_documents({})
    transferred = call_logs.count_documents({'transferred_to_human': True})
    
    pipeline = [{"$group": {"_id": None, "avg_dur": {"$avg": "$duration"}}}]
    res = list(call_logs.aggregate(pipeline))
    avg_dur = res[0]['avg_dur'] if res else 0

    return {
        "timezone": "IST (Asia/Kolkata)",
        "total_calls": total,
        "transferred_to_human": transferred,
        "average_duration": round(avg_dur, 2)
    }

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)